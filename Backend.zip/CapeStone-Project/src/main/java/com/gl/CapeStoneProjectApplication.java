package com.gl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapeStoneProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapeStoneProjectApplication.class, args);
	}

}
